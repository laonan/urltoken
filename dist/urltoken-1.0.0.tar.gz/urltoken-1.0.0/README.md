# urltoken

## Description
URL Token Encoder simplifies encoding sensitive data like emails and usernames into URL-safe tokens. Unlike encryption, it preserves data integrity for easy retrieval. Ideal for securing information in URLs without encryption complexities.

Features:

* Encode sensitive content into URL-safe tokens.
* Lightweight and easy integration into Python apps.
* Simplifies data security in web apps and APIs.


### Installation
   
    pip install urltoken

    
### Usage
    
    from urltoken import UrlTokenEncoder
    
    token = UrlTokenEncoder.encode('example@domain.com')
    print(token)

    decoded = UrlTokenEncoder.decode(token)
    print(decoded)

### Issues
https://github.com/laonan/urltoken/issues
